#! /bin/sh
eval `dbus export koolproxyR`
source /jffs/softcenter/scripts/base.sh

sh /jffs/softcenter/scripts/kp_update.sh

